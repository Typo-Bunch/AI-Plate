import sys
import json
import subprocess
from http.server import HTTPServer, BaseHTTPRequestHandler

PORT = 8788
HOST = "127.0.0.1"

def run_powershell(script: str) -> str:
    res = subprocess.check_output(
        ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
        text=True,
        stderr=subprocess.STDOUT
    )
    return res.strip()

class OfficeBridgeHandler(BaseHTTPRequestHandler):
    def _send_json(self, status: int, data: dict):
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/health":
            return self._send_json(200, {"ok": True, "service": "office", "runtime": "bundled_python"})
        self._send_json(404, {"error": "Not found"})

    def do_POST(self):
        content_length = int(self.headers.get("Content-Length", 0))
        raw_body = self.rfile.read(content_length).decode("utf-8") if content_length > 0 else "{}"
        try:
            payload = json.loads(raw_body)
        except Exception as e:
            return self._send_json(400, {"error": f"Invalid JSON: {str(e)}"})

        try:
            if self.path == "/word/create":
                file_path = payload.get("filePath", "")
                content = payload.get("content", "")
                ps = (
                    f'$word = New-Object -ComObject Word.Application; '
                    f'$doc = $word.Documents.Add(); '
                    f'$doc.Content.Text = {json.dumps(content)}; '
                    f'$doc.SaveAs([ref]{json.dumps(file_path)}); '
                    f'$doc.Close(); $word.Quit();'
                )
                run_powershell(ps)
                return self._send_json(200, {"ok": True, "filePath": file_path})

            elif self.path == "/excel/read":
                file_path = payload.get("filePath", "")
                sheet = payload.get("sheet", "")
                range_str = payload.get("range", "")
                ps = (
                    f'$excel = New-Object -ComObject Excel.Application; '
                    f'$book = $excel.Workbooks.Open({json.dumps(file_path)}); '
                    f'$sheet = $book.Worksheets.Item({json.dumps(sheet)}); '
                    f'$val = $sheet.Range({json.dumps(range_str)}).Value2; '
                    f'$book.Close($false); $excel.Quit(); '
                    f'ConvertTo-Json -Compress $val;'
                )
                output = run_powershell(ps)
                return self._send_json(200, {"ok": True, "values": json.loads(output) if output else None})

            elif self.path == "/excel/write":
                file_path = payload.get("filePath", "")
                sheet = payload.get("sheet", "")
                range_str = payload.get("range", "")
                values = payload.get("values", [])
                vals_json = json.dumps(values)
                ps = (
                    f'$excel = New-Object -ComObject Excel.Application; '
                    f'$book = $excel.Workbooks.Open({json.dumps(file_path)}); '
                    f'$sheet = $book.Worksheets.Item({json.dumps(sheet)}); '
                    f'$sheet.Range({json.dumps(range_str)}).Value2 = ConvertFrom-Json {json.dumps(vals_json)}; '
                    f'$book.Save(); $book.Close(); $excel.Quit();'
                )
                run_powershell(ps)
                return self._send_json(200, {"ok": True, "filePath": file_path, "range": range_str})

            self._send_json(404, {"error": "Unknown Office endpoint"})
        except Exception as err:
            self._send_json(400, {"error": str(err)})

    def log_message(self, format, *args):
        pass

if __name__ == "__main__":
    server = HTTPServer((HOST, PORT), OfficeBridgeHandler)
    print(f"Office bridge running on http://{HOST}:{PORT}", flush=True)
    server.serve_forever()
