# Microsoft Office setup

Requirements: Windows, Microsoft Word and Excel desktop.
Bundled Runtime: AI Plate automatically runs server.py using its bundled Python engine.

Automated Setup (Recommended):
1. In AI Plate, open Settings > App Connectors.
2. Click Install Connector ZIP and select office-bridge.connector.zip.
3. Leave Auto-start companion checked. AI Plate automatically launches and supervises the bridge on 127.0.0.1:8788.
4. Click Test Connection, then toggle Enabled.

Manual Setup (Optional):
1. Open terminal in this folder.
2. Run start-office.bat or python server.py.
3. In AI Plate, click Test Connection and toggle Enabled.
