# Microsoft Office Bridge for AI Plate

Connect AI Plate to the installed Windows desktop versions of Microsoft Word and Excel through a local Python COM bridge with automated companion lifecycle management.

## Requirements

- Windows
- Microsoft Word and Excel desktop applications
- *No external Node.js or Python installation required* — AI Plate automatically runs this companion using its bundled Python engine.

## Quick Setup Instructions (Automated)

1. In AI Plate, open **Settings > App Connectors**.
2. Click **Install Connector ZIP** and select `office-bridge.connector.zip`.
3. Keep **Auto-start companion** checked (enabled by default). AI Plate automatically boots and manages the Office COM bridge (`server.py` on 127.0.0.1:8788) in the background via bundled Python.
4. Click **Test Connection** (turns green) and toggle **Enabled**.
5. AI Plate starts and stops the bridge process automatically with the application lifecycle.

## Manual Fallback (Optional)

If running the bridge outside AI Plate or debugging:
1. Extract this ZIP.
2. Run `start-office.bat` or run `python server.py` in terminal.
3. The bridge listens on `http://127.0.0.1:8788`.

## Use It in Chat

- `Create C:\Users\you\Desktop\brief.docx with a one-page project brief.`
- `Read Sheet1 range A1:C10 from C:\Users\you\Desktop\budget.xlsx.`
- `Write these values into Sheet1 range D2:E4 in C:\Users\you\Desktop\budget.xlsx.`

## Available AI Tools

- `office_bridge_create_word_document`
- `office_bridge_read_excel_range`
- `office_bridge_write_excel_range`

The bridge binds only to 127.0.0.1. Review file paths before allowing writes.
