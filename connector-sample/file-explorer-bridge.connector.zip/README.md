# File Explorer Bridge for AI Plate

Give AI Plate a focused Windows File Explorer action for opening known files and folders with automated companion lifecycle management.

## Requirements

- Windows
- *No external runtime required* — AI Plate automatically runs this companion using its bundled Python engine.

## Quick Setup Instructions (Automated)

1. In AI Plate, open **Settings > App Connectors**.
2. Click **Install Connector ZIP** and select `file-explorer-bridge.connector.zip`.
3. Ensure **Auto-start companion** is checked (enabled by default). AI Plate automatically starts and supervises the local Explorer bridge (`server.py` on 127.0.0.1:8789) using bundled Python.
4. Click **Test Connection** (turns green) and toggle **Enabled**.

## Manual Fallback (Optional)

If running the bridge outside AI Plate:
1. Extract this ZIP.
2. Run `start-explorer.bat` or run `python server.py` in terminal.
3. The bridge listens on `http://127.0.0.1:8789`.

## Use It in Chat

- `Open C:\Users\you\Documents\Project in File Explorer.`
- `Open C:\Users\you\Downloads\report.pdf.`

## Available AI Tools

- `file_explorer_bridge_open_path`

The bridge binds only to 127.0.0.1. Confirm the exact path before opening it.
