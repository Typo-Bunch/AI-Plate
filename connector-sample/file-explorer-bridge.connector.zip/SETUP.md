# File Explorer setup

Requirements: Windows.
Bundled Runtime: AI Plate automatically runs server.py using its bundled Python engine.

Automated Setup (Recommended):
1. In AI Plate, open Settings > App Connectors.
2. Click Install Connector ZIP and select file-explorer-bridge.connector.zip.
3. Leave Auto-start companion checked. AI Plate automatically launches the bridge on 127.0.0.1:8789.
4. Click Test Connection and toggle Enabled.

Manual Setup (Optional):
1. Open terminal in this folder and run start-explorer.bat or python server.py.
2. In AI Plate, click Test Connection and toggle Enabled.
