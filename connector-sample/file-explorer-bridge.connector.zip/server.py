import sys
import json
import subprocess
from http.server import HTTPServer, BaseHTTPRequestHandler

PORT = 8789
HOST = "127.0.0.1"

class ExplorerBridgeHandler(BaseHTTPRequestHandler):
    def _send_json(self, status: int, data: dict):
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/health":
            return self._send_json(200, {"ok": True, "service": "explorer", "runtime": "bundled_python"})
        self._send_json(404, {"error": "Not found"})

    def do_POST(self):
        if self.path != "/explorer/open":
            return self._send_json(405, {"error": "Use POST /explorer/open"})

        content_length = int(self.headers.get("Content-Length", 0))
        raw_body = self.rfile.read(content_length).decode("utf-8") if content_length > 0 else "{}"
        try:
            payload = json.loads(raw_body)
            path = payload.get("path", "").strip()
            if not path:
                return self._send_json(400, {"error": "path is required"})
            subprocess.Popen(["explorer.exe", path], shell=False)
            self._send_json(200, {"ok": True, "path": path})
        except Exception as e:
            self._send_json(400, {"error": str(e)})

    def log_message(self, format, *args):
        pass

if __name__ == "__main__":
    server = HTTPServer((HOST, PORT), ExplorerBridgeHandler)
    print(f"File Explorer bridge running on http://{HOST}:{PORT}", flush=True)
    server.serve_forever()
