# Blender 3D setup

Requirements: Blender 3.x or 4.x installed locally.

Automated Setup (Recommended):
1. In AI Plate, open Settings > App Connectors.
2. Click Install Connector ZIP and select blender.connector.zip.
3. Leave Auto-start companion checked. AI Plate launches and tracks the companion bridge process on 127.0.0.1:8198.
4. Click Test Connection (turns green), then toggle Enabled.

Manual Setup (In Blender):
1. Open Blender 3D and switch to the Scripting workspace.
2. Open or paste scripts/blender_bridge.py and click Run Script.
3. In AI Plate, click Test Connection and toggle Enabled.
