# Blender 3D Connector for AI Plate

Connect AI Plate to Blender 3D via real-time WebSocket connection for instant 3D mesh creation, materials, animations, and Cycles/EEVEE rendering.

## Quick Setup Instructions

### Option A: Run inside Blender (Recommended)
1. Open Blender 3D.
2. Switch to the **Scripting** workspace tab.
3. Open or paste `scripts/blender_bridge.py` and click **▶ Run Script**.
4. The bridge starts immediately on `ws://localhost:8198/ws` (and HTTP `http://localhost:8198`).
5. In AI Plate, open **Settings > App Connectors**, click **Install Connector ZIP**, and select `blender.connector.zip`.
6. Click **Test Connection** (turns green on 127.0.0.1:8198) and toggle **Enabled**.

### Option B: Auto-Start Companion with AI Plate
1. In AI Plate, open **Settings > App Connectors**, click **Install Connector ZIP**, and select `blender.connector.zip`.
2. Leave **Auto-start companion** enabled (default). AI Plate automatically starts and supervises the Blender companion bridge.
3. Click **Test Connection** and toggle **Enabled**.

## Available AI Tools

- `blender_get_scene_info`: Inspect active 3D scene objects, materials, cameras, and render engine.
- `blender_create_mesh`: Create 3D geometric mesh primitives (cube, sphere, cylinder, plane, monkey).
- `blender_apply_material`: Create and assign PBR materials with base color and roughness.
- `blender_render_frame`: Render the active camera to an image file saved in artifacts.
- `blender_execute_script`: Execute custom Python script directly inside the Blender process using the bpy API.

The bridge binds locally to 127.0.0.1 on port 8198.
