# Obsidian setup

1. Open Obsidian > Settings > Community plugins.
2. Install and enable Local REST API.
3. Enable its HTTPS server on 127.0.0.1:27124.
4. Copy the generated API token.
5. In AI Plate Settings > App Connectors, click Install Connector ZIP and select obsidian-vault.connector.zip.
6. Paste the token into the Obsidian Local REST API Token field, test the connection, and enable the connector.
   (AI Plate automatically trusts localhost self-signed certificates for 127.0.0.1 HTTPS).

The connector uses vault-relative paths such as Projects/brief.md. Keep the token private.
