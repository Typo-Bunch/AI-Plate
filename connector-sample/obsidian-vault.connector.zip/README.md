# Obsidian Vault Connector for AI Plate

Connect AI Plate to an Obsidian vault so the agent can read and update Markdown notes through the Obsidian Local REST API.

## Quick Setup Instructions

1. Install and enable the Obsidian **Local REST API** community plugin in Obsidian.
2. Enable its HTTPS server on 127.0.0.1:27124 and copy the generated API token.
3. In AI Plate, open **Settings > App Connectors**, click **Install Connector ZIP**, and select this file (`obsidian-vault.connector.zip`).
4. Paste the API token into the **Obsidian Local REST API Token** field on the connector card, then click **Test Connection** (turns green).
   *(AI Plate automatically accepts localhost self-signed HTTPS certificates, so connection succeeds immediately).*
5. Toggle **Enabled** and ask in Chat: `Read Projects/brief.md from my Obsidian vault.`

## Available AI Tools

- `obsidian_vault_read_note`: Read a vault-relative Markdown note.
- `obsidian_vault_write_note`: Create or replace a Markdown note.

Keep the token private. Do not commit it or include it in exported packages.
